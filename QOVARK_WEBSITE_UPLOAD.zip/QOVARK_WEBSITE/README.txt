QOVARK WEBSITE — GITHUB PAGES

Files:
- index.html: complete responsive QOVARK public homepage
- qovark-logo.png: QOVARK orbital Q logo used by the homepage and favicon

IMPORTANT:
- Upload BOTH files to the ROOT of the qovark-website GitHub repository.
- Do not upload these files to your existing backend repository.
- Do not include API keys, passwords, Firebase service-account files, private keys, or backend .env files.
- The homepage is static and requires no build command or server-side runtime.

After upload:
1. Open repository Settings > Pages.
2. Under Build and deployment, choose Deploy from a branch.
3. Choose branch main and folder /(root), then Save.
4. Wait until GitHub Pages reports the site published.
5. Open the Pages URL and check that the page and logo load.
6. Only after that, configure qovark.com as the custom domain in GitHub Pages.

The website currently avoids publishing personal contact details or making claims about certifications, legal registration, or public app-store availability.
